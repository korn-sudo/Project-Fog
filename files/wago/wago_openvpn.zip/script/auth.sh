#!/bin/bash
. /etc/openvpn/script/config.sh
case $CATEGORY in
    VIP )
        cat=vip_;;
    PRIVATE )
        cat=private_;;
esac
if [[ `mysql -u$USER -p$PASS -h $HOST -D $DB -e "SHOW TABLES LIKE 'users'"` ]]; then
    Query="SELECT users.user_name FROM users WHERE users.user_name='$username' AND users.auth_vpn=md5('$password') AND users.is_validated=1 AND users.is_freeze=0 AND users.is_active=1 AND users.is_ban=0 AND users.${cat}duration > 0"
else
    [[ $cat ]] && cat=is_
    Query="SELECT user.username FROM user WHERE user.username='$username' AND user.auth_vpn=md5('$password') AND user.confirmcode='y' AND user.status='live' AND user.is_freeze=1 AND user.is_active=1 AND user.is_ban=1 AND user.is_suspend=1 AND user.${cat}duration > 0"
fi

auth_vpn=`mysql -u$USER -p$PASS -D $DB -h $HOST --skip-column-name -e "$Query"`

[ "$auth_vpn" != '' ] && [ "$auth_vpn" = "$username" ] && echo "user : $auth_vpn" && echo 'authentication ok.' && exit 0 || echo 'authentication failed.'; exit 1
