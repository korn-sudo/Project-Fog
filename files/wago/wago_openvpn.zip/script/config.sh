#!/bin/bash
##Dababase Server
HOST='162.246.16.67'
USER='wagopan_wago'
PASS='wagopanel2020'
DB='wagopan_wago'
PORT='3306'
case PREMIUM in
    PREMIUM )
        cat=premium;;
    VIP )
        cat=vip;;
    PRIVATE )
        cat=private;;
esac
