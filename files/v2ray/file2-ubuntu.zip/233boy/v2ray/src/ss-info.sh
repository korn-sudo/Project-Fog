#!/bin/bash
#Script by blackestsaint

[[ -z $ip ]] && get_ip
if [[ $shadowsocks ]]; then

	echo
	echo -e "              ☁️☁️☁️ Project Fog ☁️☁️☁️" | lolcat      
	echo ""
	echo
	echo "---------- Shadowsocks Configuration information -------------"
	echo
	echo -e "$yellow IP : $cyan${ip}$none"
	echo
	echo -e "$yellow Port : $cyan$ssport$none"
	echo
	echo -e "$yellow Password : $cyan$sspass$none"
	echo
	echo -e "$yellow Encryption Protocol : $cyan${ssciphers}$none"
	echo
	echo
fi
