#!/bin/bash
#Script by blackestsaint


# vmess
_load vmess-config.sh
_get_client_file() {
    local _link="$(cat $v2ray_client_config | tr -d [:space:] | base64 -w0)"
    local link="https://233boy.github.io/tools/json.html#${_link}"

echo ""
echo ""
echo -e "            ░▒▓█ ☁️ Project Fog ☁️ █▓▒░ " 
echo ""
    echo
    echo "---------- V2Ray Config File Link: -------------"
    echo
    echo -e ${cyan}$link${none}
    echo
    echo
    echo
}
