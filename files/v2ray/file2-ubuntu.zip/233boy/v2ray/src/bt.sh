#!/bin/bash
#Script by blackestsaint

_ban_bt_main() {
	if [[ $ban_bt ]]; then
		local _info="$green Turned On $none"
	else
		local _info="$red Turned Off $none"
	fi
	_opt=''
	while :; do
		echo
		echo -e "$yellow 1. $none Turn on BT blocking"
		echo
		echo -e "$yellow 2. $none Turn off BT blocking"
		echo
		echo -e "BT Blocking status: $_info"
		echo
		read -p "$(echo -e "Choose [${magenta}1-2$none]:")" _opt
		if [[ -z $_opt ]]; then
			error
		else
			case $_opt in
			1)
				if [[ $ban_bt ]]; then
					echo
					echo -e " BT Blocking status: $_info"
					echo
				else
					echo
					echo
					echo -e "$yellow  BT Blocking = $cyan On $none"
					echo "----------------------------------------------------------------"
					echo
					pause
					backup_config +bt
					ban_bt=true
					config
					echo
					echo
					echo -e "$green  BT Blocking : ON $none"
					echo
				fi
				break
				;;
			2)
				if [[ $ban_bt ]]; then
					echo
					echo
					echo -e "$yellow  BT Blocking = $cyan Off $none"
					echo "----------------------------------------------------------------"
					echo
					pause
					backup_config -bt
					ban_bt=''
					config
					echo
					echo
					echo -e "$red  BT Blocking : Off $none"
					echo
				else
					echo
					echo -e " BT Blocking status: $_info"
					echo
				fi
				break
				;;
			*)
				error
				;;
			esac
		fi
	done
}
