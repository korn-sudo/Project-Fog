#!/bin/bash
#Script by blackestsaint



_get_latest_version() {

	v2ray_repos_url="https://api.github.com/repos/v2fly/v2ray-core/releases/latest?v=$RANDOM"
	v2ray_latest_ver="$(curl -s $v2ray_repos_url | grep 'tag_name' | cut -d\" -f4)"

	if [[ ! $v2ray_latest_ver ]]; then
		echo
		echo -e " $redFailed to get the latest version of V2Ray!!!!!!$none"
		echo
		exit 1
	fi
}

_download_v2ray_file() {

	[[ ! $v2ray_latest_ver ]] && _get_latest_version
	v2ray_tmp_file="/tmp/v2ray.zip"
	v2ray_download_link="https://github.com/v2fly/v2ray-core/releases/download/$v2ray_latest_ver/v2ray-linux-${v2ray_bit}.zip"

	if ! wget --no-check-certificate -O "$v2ray_tmp_file" $v2ray_download_link; then
		echo -e "
        $red Failed to download resources...$none
        " && exit 1
	fi

	unzip -o $v2ray_tmp_file -d "/usr/bin/v2ray/"
	chmod +x /usr/bin/v2ray/{v2ray,v2ctl}
	if [[ ! $(cat /root/.bashrc | grep v2ray) ]]; then
		echo "alias v2ray=$_v2ray_sh" >>/root/.bashrc
	fi
}

_install_v2ray_service() {

	# cp -f "/usr/bin/v2ray/systemd/v2ray.service" "/lib/systemd/system/"
	# sed -i "s/on-failure/always/" /lib/systemd/system/v2ray.service
	cat >/lib/systemd/system/v2ray.service <<-EOF
[Unit]
Description=V2Ray Service
Documentation=https://www.v2ray.com/ https://www.v2fly.org/
After=network.target nss-lookup.target

[Service]
# If the version of systemd is 240 or above, then uncommenting Type=exec and commenting out Type=simple
#Type=exec
Type=simple
User=root
#User=nobody
CapabilityBoundingSet=CAP_NET_ADMIN CAP_NET_BIND_SERVICE
AmbientCapabilities=CAP_NET_ADMIN CAP_NET_BIND_SERVICE
NoNewPrivileges=true
ExecStart=/usr/bin/v2ray/v2ray -config /etc/v2ray/config.json
Restart=always

[Install]
WantedBy=multi-user.target
EOF
	systemctl enable v2ray
}

_update_v2ray_version() {

	_get_latest_version
	if [[ $v2ray_ver != $v2ray_latest_ver ]]; then
		echo
		echo -e " $green New Version available.......$none"
		echo
		_download_v2ray_file
		do_service restart v2ray
		echo
		echo -e " $green The update is successful...Current V2Ray version: ${cyan}$v2ray_latest_ver$none"
		echo
		echo
	else
		echo
		echo -e " $green No new version found....$none"
		echo
	fi
}

_mkdir_dir() {
	mkdir -p /var/log/v2ray
	mkdir -p /etc/v2ray
}
