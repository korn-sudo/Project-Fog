#!/bin/bash
#Script by blackestsaint

_qr_create() {

	local vmess="vmess://$(cat /etc/v2ray/vmess_qr.json | base64 -w 0)"
	local link="https://233boy.github.io/tools/qr.html#${vmess}"
	clear
	echo
	echo -e "                           ☁️☁️☁️ Project Fog ☁️☁️☁️" | lolcat      
    echo ""
	echo " ------------------------------- V2Ray QR Code --------------------------------"
	echo
	echo
	echo -e "Step 1: Copy link below to your browser and enter."
	echo
	echo -e "${cyan}$link${none}"
	echo
	echo -e "Step 2: Copy link generated FROM your BROWSER TO your V2Ray apps clipboard."
	echo
	echo
	echo
	echo -e "Note: Link above not work direct in your V2Ray apps clipboard "
	echo -e "      Link above need copy to browser and your browser generate the link. "
	echo
	echo "   ------------------------ ☁️☁️☁️ Project Fog ☁️☁️☁️ ------------------------"  | lolcat      

	rm -rf /etc/v2ray/vmess_qr.json
}
_ss_qr() {

	local ss_link="ss://$(echo -n "${ssciphers}:${sspass}@${ip}:${ssport}" | base64 -w 0)#Project-Fog"
	local link="https://233boy.github.io/tools/qr.html#${ss_link}"
	clear
	echo
	echo
	echo -e "                                  ☁️☁️☁️ Project Fog ☁️☁️☁️" | lolcat      
    echo ""
	echo " ------------------------------- V2Ray Protocol: Shadowsocks  Link --------------------------------"
	echo
	echo
	echo -e "$yellow Copy link below to your V2Ray Application $none" 
	echo
	echo -e "${cyan}$ss$none"
	echo
	echo
	echo -e "   ------------------------ ☁️☁️☁️ Project Fog ☁️☁️☁️ ------------------------"  | lolcat   



}
